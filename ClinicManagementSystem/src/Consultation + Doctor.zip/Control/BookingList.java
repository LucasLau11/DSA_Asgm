package Control;

import adt.MyLinkedList;
import Entity.Consultation;

public class BookingList {

    // This is the one shared list for the whole program
    public static MyLinkedList<Consultation> bookingList = new MyLinkedList<>();

}
