//package dsa_asgmt;
//
//import Utility.calendar;
//import Utility.ClearScreen;
//import Control.*;
//import Entity.*;
//import Boundary.*;
//import adt.*;
//
//import java.time.LocalDate;
//import java.time.YearMonth;
//import java.time.format.TextStyle; //to translate date to english words
//import java.util.*;
//
//public class backup {
//
//    public static final String RED = "\u001B[41m";
//    public static final String RED_TEXT = "\u001B[31m";
//    public static final String GREEN = "\u001B[42m";
//    public static final String GREEN_TEXT = "\u001B[32m";
//    public static final String BLUE_TEXT = "\u001B[34m";
//    public static final String NO_COLOR = "\u001B[0m";
//
//    enum BookStatus {
//        BOOKED,
//        AVAILABLE,
//        BREAK
//    }
//
//    // timetable format row column lines
//    public static void printLine(String corner, int width, int columns) {
//        for (int i = 0; i < columns; i++) {
//            System.out.print(corner + "-".repeat(width));
//        }
//        System.out.println(corner);
//    }
//
//    // doctor's timetable
//    public static void printTimetable(String[] doctors, BookStatus[][] bookingStatus) {
//        String[] periods = {
//            "08:00-09:00",
//            "09:00-10:00",
//            "10:00-11:00",
//            "11:00-12:00",
//            "12:00-13:00",
//            "13:00-14:00",
//            "14:00-15:00",
//            "15:00-16:00",
//            "16:00-17:00"};
//        int colWidth = 12;
//
//        printLine("+", (colWidth + 1), doctors.length + 1);
//        System.out.printf("| %-" + colWidth + "s", "Time/Doctor");
//        for (String doctor : doctors) {
//            System.out.printf("| %-" + colWidth + "s", doctor);
//        }
//        System.out.println("|");
//        printLine("+", (colWidth + 1), doctors.length + 1);
//
//        for (int i = 0; i < periods.length; i++) {
//            System.out.printf("| %-" + colWidth + "s", periods[i]);
//            for (int j = 0; j < doctors.length; j++) {
//                BookStatus status = bookingStatus[i][j];
//                String color, label;
//
//                switch (status) {
//                    case AVAILABLE:
//                        color = GREEN;
//                        label = "";
//                        break;
//                    case BOOKED:
//                        color = RED;
//                        label = "";
//                        break;
//                    case BREAK:
//                        color = NO_COLOR;
//                        label = " BREAK ";
//                        break;
//                    default:
//                        color = NO_COLOR;
//                        label = " TBA ";
//                }
//                System.out.printf("|%s%-" + (colWidth + 1) + "s%s", color, label, NO_COLOR);
//            }
//            System.out.println("|");
//            printLine("+", (colWidth + 1), doctors.length + 1);
//        }
//
//        System.out.printf("%s      %s = %s", GREEN, NO_COLOR, "Available");
//        System.out.print("  ");
//        System.out.printf("%s      %s = %s\n", RED, NO_COLOR, "Booked");
//    }
//
//    public static void main(String[] args) {
//
//        Scanner scan = new Scanner(System.in);
//        Map<LocalDate, BookStatus[][]> timetablePerDate = new HashMap<>();
//
//        while (true) {
//
//            System.out.println("===================");
//            System.out.println(" Consultation Mode ");
//            System.out.println("===================");
//
//            System.out.println("1. Make An Appointment");
//            System.out.println("2. Check Booked Appointment(s)");
//            System.out.println("3. Exit");
//            System.out.print("\nChoose an option (1/2/..) > ");
//
//            int option = scan.nextInt();
//
//            if (option == 3) {
//                System.out.println(BLUE_TEXT + "\n=======================================================================" + NO_COLOR);
//                System.out.println(BLUE_TEXT + "|| Thanks for booking with us! Please proceed back to our Home Menu! ||" + NO_COLOR);
//                System.out.println(BLUE_TEXT + "=======================================================================\n" + NO_COLOR);
//
//                System.out.print("Please press ENTER to proceed... ");
//                scan.nextLine();
//                scan.nextLine(); // debug (prevent next input kena skipped)
//                System.out.println("\n");
//
//                break;
//
//            } else if (option == 1) {
//
//                scan.nextLine(); // debug (prevent next input kena skipped)
//
//                YearMonth currentMonth = YearMonth.now();
//
//                // get today's month
//                while (true) {
//
//                    System.out.println(BLUE_TEXT + "\n===================================================" + NO_COLOR);
//                    System.out.println(BLUE_TEXT + " ** Appointments must be made 1 day in advance! **" + NO_COLOR);
//                    System.out.println(BLUE_TEXT + "===================================================" + NO_COLOR);
//
//                    calendar.displayCalendar(currentMonth);
//
//                    // 2 different doctors will be switching each month
//                    if (currentMonth.getMonthValue() % 2 == 1) {
//                        System.out.println(BLUE_TEXT + ">> Doctors Available This Month: Dr Zain, Dr John <<" + NO_COLOR + "\n");
//                    } else {
//                        System.out.println(BLUE_TEXT + ">> Doctors Available This Month: Dr Amalia, Dr Zoe <<" + NO_COLOR + "\n");
//                    }
//
//                    System.out.print("Enter 'next' or 'prev' to navigate through months, or enter a day (1-31) to choose a date > ");
//                    String input = scan.nextLine();
//
//                    if (input.equalsIgnoreCase("next")) {
//                        currentMonth = currentMonth.plusMonths(1);
//                    } else if (input.equalsIgnoreCase("prev")) {
//                        currentMonth = currentMonth.minusMonths(1);
//                    } else {
//                        try {
//                            int day = Integer.parseInt(input);
//                            if (day >= 1 && day <= currentMonth.lengthOfMonth()) {
//                                LocalDate selectedDate = currentMonth.atDay(day);
//                                LocalDate today = LocalDate.now();
//
//                                if (!selectedDate.isAfter(today)) {
//
//                                    System.out.println("\n" + RED_TEXT + ">> You cannot choose a date before or today! Please Try Again. <<" + NO_COLOR);
//                                    continue;
//                                }
//
//                                System.out.println("\n" + BLUE_TEXT + ">> You selected (YYYY-MM-DD) > " + selectedDate + " <<" + NO_COLOR);
//
//                                // simulated timetable based on selected month
//                                String[] doctors;
//                                if (currentMonth.getMonthValue() % 2 == 1) {
//                                    doctors = new String[]{"Dr Zain", "Dr John"};
//                                } else {
//                                    doctors = new String[]{"Dr Amalia", "Dr Zoe"};
//                                }
//
//                                BookStatus[][] bookingStatus;
//                                if (timetablePerDate.containsKey(selectedDate)) {
//                                    bookingStatus = timetablePerDate.get(selectedDate);
//                                } else {
//                                    bookingStatus = new BookStatus[9][doctors.length];
//                                    for (int i = 0; i < 9; i++) {
//                                        for (int j = 0; j < doctors.length; j++) {
//                                            bookingStatus[i][j] = BookStatus.AVAILABLE;
//                                        }
//                                    }
//                                    // Set lunch break
//                                    for (int j = 0; j < doctors.length; j++) {
//                                        bookingStatus[4][j] = BookStatus.BREAK;
//                                    }
//                                    timetablePerDate.put(selectedDate, bookingStatus);
//                                }
//
//                                printTimetable(doctors, bookingStatus);
//
//                                // Let user choose an appointment by selecting row and column
//                                System.out.println("\nSelect an appointment:");
//                                System.out.print("Enter time slot row number (1-9) > ");
//                                int row = Integer.parseInt(scan.nextLine());
//                                row -= 1;
//
//                                System.out.print("Enter doctor column number (1-" + doctors.length + ") > ");
//                                int col = Integer.parseInt(scan.nextLine());
//                                col -= 1;
//
//                                if (row < 0 || row >= 9 || col < 0 || col >= doctors.length) {
//                                    System.out.println(RED_TEXT + ">> Invalid row or column number. <<" + NO_COLOR);
//                                    return;
//                                }
//
//                                // Check if already booked or not available
//                                BookStatus status = bookingStatus[row][col];
//                                if (status != BookStatus.AVAILABLE || status == BookStatus.BREAK) {
//                                    System.out.println(RED_TEXT + "\n>> Slot is not available. Please choose another one. <<\n" + NO_COLOR);
//                                } else {
//                                    // Mark as booked
//                                    bookingStatus[row][col] = BookStatus.BOOKED;
//
//                                    String[] periods = {
//                                        "08:00-09:00",
//                                        "09:00-10:00",
//                                        "10:00-11:00",
//                                        "11:00-12:00",
//                                        "12:00-13:00",
//                                        "13:00-14:00",
//                                        "14:00-15:00",
//                                        "15:00-16:00",
//                                        "16:00-17:00"
//                                    };
//
//                                    String chosenDoctor = doctors[col];
//                                    String chosenTime = periods[row];
//
//                                    System.out.println("\n" + GREEN_TEXT + ">> Appointment confirmed! <<" + NO_COLOR);
//                                    System.out.println("   Doctor  : " + chosenDoctor);
//                                    System.out.println("   Date    : " + selectedDate);
//                                    System.out.println("   Time    : " + chosenTime);
//                                    System.out.println(GREEN_TEXT + ">> Appointment confirmed! <<\n" + NO_COLOR);
//
//                                    System.out.println(RED_TEXT + "===============================================================================================" + NO_COLOR);
//                                    System.out.println(RED_TEXT + "|| !!!! PLEASE arrive at the clinic on-time accordingly and report to the front counter !!!! ||" + NO_COLOR);
//                                    System.out.println(RED_TEXT + "|| !!!!         Consultation will be forfeited after 10 minutes of late arrival         !!!! ||" + NO_COLOR);
//                                    System.out.println(RED_TEXT + "===============================================================================================\n" + NO_COLOR);
//                                }
//
//                                System.out.print("Please press ENTER to proceed... ");
//                                scan.nextLine();
//                                scan.nextLine(); // debug (prevent next input kena skipped)
//                                
//                                ClearScreen.clearScreen();
//
//                                //end of boooking
//                                break;
//                            } else {
//                                System.out.println("\n" + RED_TEXT + ">> Invalid day. Please Try Again." + NO_COLOR);
//                            }
//                        } catch (NumberFormatException e) {
//                            System.out.println("\n" + RED_TEXT + ">> Invalid input (next or prev). Please Try Again. <<" + NO_COLOR);
//                        }
//                    }
//                }
//            } else if (option == 2) {
//                System.out.println(BLUE_TEXT + "\n=======================================================================" + NO_COLOR);
//
//                System.out.print("Please press ENTER to proceed... ");
//                scan.nextLine();
//                scan.nextLine(); // debug (prevent next input kena skipped)
//                System.out.println("\n");
//
//            } else {
//                System.out.println("\n" + RED_TEXT + ">> Invalid option. Please Try Again.\n" + NO_COLOR);
//            }
//        }
//    }
//}
